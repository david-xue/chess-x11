#ifndef __POSN_H__
#define __POSN_H__

struct Posn {
 char col;
 int row;
};

#endif
