#ifndef __GRAPHDISPLAY_H__
#define __GRAPHDISPLAY_H__
#include "display.h"

class GraphDisplay: public Display {
};

#endif
